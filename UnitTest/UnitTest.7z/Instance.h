#pragma once
#define MAX_INSTANCE 4096 //�迭�� �ִ� ����
class Instance :public Renderer
{
public:
	Instance();
	~Instance();

	void Update();
	void Render();

	uint Push();//�ѹ� ȣ��� drawCount++
	Transform* GetTransform(uint index);
private:
	uint drawCount;
	
	Transform* transforms[MAX_INSTANCE];
	
	Matrix worlds[MAX_INSTANCE];

	
	VertexBuffer* instanceBuffer;


};

