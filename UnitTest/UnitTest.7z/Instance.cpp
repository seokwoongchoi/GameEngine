#include "stdafx.h"
#include "Instance.h"

Instance::Instance()
	:Renderer(L"024_Instance.fx")
	, drawCount(1000)
{
	for (uint i = 0; i < MAX_INSTANCE; i++)
	{
		//transforms[i] = new Transform(shader);
		transforms[i] = new Transform();
		D3DXMatrixIdentity(&worlds[i]);
	}

	VertexTexture vertices[4];
	vertices[0].Position = D3DXVECTOR3(-0.5f, -0.5f, 0.0f);
	vertices[1].Position = D3DXVECTOR3(-0.5f, +0.5f, 0.0f);
	vertices[2].Position = D3DXVECTOR3(+0.5f, -0.5f, 0.0f);
	vertices[3].Position = D3DXVECTOR3(+0.5f, +0.5f, 0.0f);

	vertices[0].Uv = D3DXVECTOR2(0, 1);
	vertices[1].Uv = D3DXVECTOR2(0, 0);
	vertices[2].Uv = D3DXVECTOR2(1, 1);
	vertices[3].Uv = D3DXVECTOR2(1, 0);

	vertexBuffer = new VertexBuffer(vertices, 4, sizeof(VertexTexture));

	
	instanceBuffer = new VertexBuffer(worlds,MAX_INSTANCE,sizeof(Matrix),1,true);
	
	uint indices[6] = { 0,1,2,2,1,3 };
	indexBuffer = new IndexBuffer(indices,6);

	//worlds�� �������� �ν��Ͻ� �Ѵ�
}

Instance::~Instance()
{
}

void Instance::Update()
{
	Super::Update();

	for (uint i = 0; i < drawCount; i++)
	{
		memcpy(&worlds[i], &transforms[i]->World(), sizeof(Matrix));
	}
	D3D11_MAPPED_SUBRESOURCE subResource;
	D3D::GetDC()->Map(instanceBuffer->Buffer(), 0, D3D11_MAP_WRITE_DISCARD, 0, &subResource);
	{
		memcpy(subResource.pData, worlds, sizeof(Matrix)*MAX_INSTANCE);
	}
	D3D::GetDC()->Unmap(instanceBuffer->Buffer(), 0);
}

void Instance::Render()
{
	Super::Render();

	/*for (uint i = 0; i < drawCount; i++)
	{
		transforms[i]->Render();
		shader->DrawIndexed(0, 0, 6);
	}*/
	instanceBuffer->Render();
	shader->DrawIndexedInstanced(0, 0, 6, drawCount);
}

uint Instance::Push()
{
	drawCount++;

	return drawCount-1;
}

Transform * Instance::GetTransform(uint index)
{
	return transforms[index];
}
